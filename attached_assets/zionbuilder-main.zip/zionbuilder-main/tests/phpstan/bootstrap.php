<?php

// TODO Do not use core constants.
define( 'WP_MEMORY_LIMIT', '64M' );
define( 'AUTOSAVE_INTERVAL', 0 );
define( 'WP_PLUGIN_DIR', '' );

window.zb = window.parent.zb;

export {};

import Section from './components/Section.vue';

window.zb.editor.registerElementComponent({
	elementType: 'zion_section',
	component: Section,
});

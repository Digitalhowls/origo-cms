import IconList from './components/IconList.vue';

window.zb.editor.registerElementComponent({
	elementType: 'icon_list',
	component: IconList,
});

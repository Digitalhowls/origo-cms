import Testimonial from './components/Testimonial.vue';

window.zb.editor.registerElementComponent({
	elementType: 'testimonial',
	component: Testimonial,
});

import Gallery from './components/gallery.vue';

window.zb.editor.registerElementComponent({
	elementType: 'gallery',
	component: Gallery,
});

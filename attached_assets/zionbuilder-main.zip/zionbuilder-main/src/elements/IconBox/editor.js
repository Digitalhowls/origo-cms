import iconBox from './components/iconBox.vue';

window.zb.editor.registerElementComponent({
	elementType: 'icon_box',
	component: iconBox,
});

import ImageSlider from './components/ImageSlider.vue';

window.zb.editor.registerElementComponent({
	elementType: 'image_slider',
	component: ImageSlider,
});

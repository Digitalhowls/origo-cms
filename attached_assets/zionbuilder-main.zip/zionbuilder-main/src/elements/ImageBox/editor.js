import ImageBox from './components/ImageBox.vue';

window.zb.editor.registerElementComponent({
	elementType: 'image_box',
	component: ImageBox,
});

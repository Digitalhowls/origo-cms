import customHtml from './components/customHtml.vue';

window.zb.editor.registerElementComponent({
	elementType: 'custom_html',
	component: customHtml,
});

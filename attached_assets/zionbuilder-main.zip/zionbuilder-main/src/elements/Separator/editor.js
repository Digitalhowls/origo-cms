import Separator from './components/Separator.vue';

window.zb.editor.registerElementComponent({
	elementType: 'zion_separator',
	component: Separator,
});

import Container from './components/Container.vue';

window.zb.editor.registerElementComponent({
	elementType: 'container',
	component: Container,
});

import Link from './components/Link.vue';

window.zb.editor.registerElementComponent({
	elementType: 'zion_link',
	component: Link,
});

import Column from './components/column.vue';

window.zb.editor.registerElementComponent({
	elementType: 'zion_column',
	component: Column,
});

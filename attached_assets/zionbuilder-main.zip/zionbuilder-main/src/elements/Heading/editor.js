import Heading from './components/Heading.vue';

window.zb.editor.registerElementComponent({
	elementType: 'zion_heading',
	component: Heading,
});

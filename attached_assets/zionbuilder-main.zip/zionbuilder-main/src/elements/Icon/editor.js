import Icon from './components/Icon.vue';

window.zb.editor.registerElementComponent({
	elementType: 'icon',
	component: Icon,
});

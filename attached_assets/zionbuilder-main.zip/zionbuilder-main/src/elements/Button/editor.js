import Button from './components/Button.vue';

window.zb.editor.registerElementComponent({
	elementType: 'zion_button',
	component: Button,
});

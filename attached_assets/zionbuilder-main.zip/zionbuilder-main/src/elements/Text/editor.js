import Text from './components/Text.vue';

window.zb.editor.registerElementComponent({
	elementType: 'zion_text',
	component: Text,
});

import Counter from './components/counter.vue';

window.zb.editor.registerElementComponent({
	elementType: 'counter',
	component: Counter,
});

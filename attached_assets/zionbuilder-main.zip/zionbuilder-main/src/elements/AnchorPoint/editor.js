import anchorPoint from './components/anchorPoint.vue';

window.zb.editor.registerElementComponent({
	elementType: 'anchor_point',
	component: anchorPoint,
});

import Alert from './components/Alert.vue';

window.zb.editor.registerElementComponent({
	elementType: 'alert',
	component: Alert,
});

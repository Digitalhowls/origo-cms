import Video from './components/Video.vue';

window.zb.editor.registerElementComponent({
	elementType: 'zion_video',
	component: Video,
});

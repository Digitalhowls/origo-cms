import ProgressBars from './components/ProgressBars.vue';

window.zb.editor.registerElementComponent({
	elementType: 'progress_bars',
	component: ProgressBars,
});

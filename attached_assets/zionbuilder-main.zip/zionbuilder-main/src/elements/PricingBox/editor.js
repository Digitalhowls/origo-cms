import PricingBox from './components/PricingBox.vue';

window.zb.editor.registerElementComponent({
	elementType: 'pricing_box',
	component: PricingBox,
});

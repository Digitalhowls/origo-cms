import googleMaps from './components/googleMaps.vue';

window.zb.editor.registerElementComponent({
	elementType: 'google_maps',
	component: googleMaps,
});

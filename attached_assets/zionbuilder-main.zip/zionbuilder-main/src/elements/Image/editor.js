import Image from './components/Image.vue';

window.zb.editor.registerElementComponent({
	elementType: 'zion_image',
	component: Image,
});

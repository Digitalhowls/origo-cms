import * as VueRouter from '/@zb/vue-router';

window.zb = window.zb || {};
window.zb.VueRouter = VueRouter;

import * as pinia from '/@zb/pinia';

window.zb = window.zb || {};
window.zb.pinia = pinia;

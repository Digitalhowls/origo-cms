export { default as Tab } from './Tab.vue'
export { default as Tabs } from './Tabs.vue'

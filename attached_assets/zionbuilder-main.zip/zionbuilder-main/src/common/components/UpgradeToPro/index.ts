export { default as UpgradeToPro } from './UpgradeToPro.vue';

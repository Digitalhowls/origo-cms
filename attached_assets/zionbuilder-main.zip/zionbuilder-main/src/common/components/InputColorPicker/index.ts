export { default as InputColorPicker } from './InputColorPicker.vue';
export { default as Color } from './Color.vue';

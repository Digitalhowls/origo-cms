export { default as Injection } from './Injection.vue'

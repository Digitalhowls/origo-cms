export { default as InputTextShadow } from './InputTextShadow.vue';

export { default as Notice } from './Notice.vue';

export { default as InputMedia } from './InputMedia.vue';

export { default as InputRange } from './InputRange.vue';
export { default as InputRangeDynamic } from './InputRangeDynamic.vue';

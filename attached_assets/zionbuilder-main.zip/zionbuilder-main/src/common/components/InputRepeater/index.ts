export { default as InputRepeater } from './Repeater.vue';

import Tooltip from './components/Tooltip.vue';
import { PopperDirective } from './directive';

export { Tooltip, PopperDirective };

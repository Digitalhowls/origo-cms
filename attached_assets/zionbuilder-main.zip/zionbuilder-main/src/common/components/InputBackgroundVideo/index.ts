export { default as InputBackgroundVideo } from './InputBackgroundVideo.vue';

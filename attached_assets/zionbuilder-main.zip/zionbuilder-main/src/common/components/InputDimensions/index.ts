export { default as InputDimensions } from './InputDimensions.vue';

export { default as InputSelect } from './InputSelect.vue';

export { default as InputLink } from './InputLink.vue';

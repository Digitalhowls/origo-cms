export { default as InputIcon } from './InputIcon.vue';

import * as Vue from '/@zb/vue';

window.zb = window.zb || {};
window.zb.vue = Vue;

export default {
	isMac: window.navigator.userAgent.indexOf('Macintosh') >= 0,
};

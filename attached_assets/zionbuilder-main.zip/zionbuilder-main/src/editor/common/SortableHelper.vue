<template>
	<Icon icon="plus" :bg-size="40" :rounded="true" color="#fff"></Icon>
</template>

<style lang="scss">
.zion-editor__sortable-helper {
	display: flex;
	align-items: center;
	justify-content: center;
	width: 28px;
	height: 28px;
	font-size: 14px;
	background-color: var(--zb-secondary-color);
	border-radius: 50%;
	cursor: none;
}
</style>

import { ZionElement } from './ZionElement';

export class ZionWidgetElement extends ZionElement {
	public widgetID: string;
	constructor(elementData: ZionElementConfig, parentUID: string) {}
}

const { ServerRequest } = window.zb.utils;

const serverRequest = new ServerRequest();

export { serverRequest };
